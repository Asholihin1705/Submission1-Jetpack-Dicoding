package com.example.nobaryuh.Data

data class Cataloque (
    var id: String,
    var poster: Int,
    var title: String,
    var release: String,
    var genre: String,
    var duration: String,
    var score: String,
    var overview: String,
    var director: String
)